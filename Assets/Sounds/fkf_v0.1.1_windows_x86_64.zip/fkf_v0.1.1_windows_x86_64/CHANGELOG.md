### v0.1.1 - 04/23/2021

- Weapon change now has a smoother transition
- When aiming with scope or reloading, 3rd person character changes its animation to provide feedack to the rival
- Now you can see the effects of all active cards pressing the Tab button
- Replaced "Bullet Time" card image
- Bullet Time effect lasts longer & increases accuracy
- Used cards stay longer on screen
- Improved player position synchronization
- Added extra feedback to headshotsww
- Fixed: sometimes the character renders in the VS screen appeared cut in half, or totally invisible
- Fixed: own ragdoll resets correctly with each kill
- Fixed: decimals showing in health bar
- Fixed: death cam can go through walls

### v0.1.0 - 04/21/2021

- Initial release!